  
  if(location.pathname!=="/vid-player.html")
{
  let leftitem = document.querySelector(".LeftItems");
    let openclose=document.querySelector("#openclose")
    
    if (openclose) {
        openclose.addEventListener("click", () => {
            
            if (leftitem.classList.contains("LeftItemshide"))
                leftitem.classList.remove("LeftItemshide") 
            else 
                leftitem.classList.add("LeftItemshide")
            
        });
    } 

    addEventListener("resize",()=>{
        if(innerWidth>=1000)
        {
            console.log("a")
            if (leftitem.classList.contains("LeftItemshide"))
                leftitem.classList.remove("LeftItemshide") 
            
        }

    })
}
else
{
    let leftitem = document.querySelector(".LeftItems");
    leftitem.classList.add("LeftItemshide")
    
    let openclose=document.querySelector("#openclose")
    let body=document.querySelector("#bodybackgroundchangewhenleftclicked")
    if (openclose) {
        openclose.addEventListener("click", () => {
            leftitem.classList.add("LeftItemsz")
            if (leftitem.classList.contains("LeftItemshide"))
            {

                console.log("a")
              
                leftitem.classList.remove("LeftItemshide")
                body.classList.add("bodybackground")
              
            }
                 
            else 
            {

                
                console.log("b")
             
                leftitem.classList.add("LeftItemshide")
                body.classList.remove("bodybackground")
                
               
              
            }
        });
    } 
   

   
}
    